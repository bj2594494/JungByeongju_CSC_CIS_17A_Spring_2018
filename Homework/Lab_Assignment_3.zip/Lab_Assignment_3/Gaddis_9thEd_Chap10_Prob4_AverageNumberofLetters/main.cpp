/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 26, 2018, 12:38 AM
 * Purpose: Average Number of Letters Problem
 */

//System Libraries
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void count(char *);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE = 100;
    char array[SIZE];
    //User Input
    cout<<"This program displays the number of words in your string."<<endl;
    cout<<"Enter your string."<<endl;
    cin.getline(array, SIZE);
    //Process/Map inputs to outputs
    cout<<"Your string has ";
    count(array);
    //Output data
    
    //Exit stage right!
    return 0;
}

void count(char *a){
    float numWord=1;
    float length=strlen(a);
    float avgLttr;
    while(*a != '\0'){
        if(*a == ' '){
            numWord++;
        }
        a++;
    }
    avgLttr=(length-(numWord-1))/numWord;
    cout<<numWord<<" words."<<endl;
    cout<<"The average letters in your string is "<<avgLttr<<"."<<endl;
}

