/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 11:20 PM
 * Purpose: String Length Problem
 */

//System Libraries
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
int gtLngth(char []);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int NUMBER=100;
    char word[NUMBER];
    int length;
    //User Input
    cout<<"This program counts the length of a string."<<endl;
    cout<<"Enter any words."<<endl;
    cin.getline(word , NUMBER);
    
    //Process/Map inputs to outputs
    length=gtLngth(word);
    //Output data
    cout<<"The length of your string is "<<length<<"."<<endl;
    //Exit stage right!
    return 0;
}

int gtLngth(char a[]){
    int number;
    number=strlen(a);
    return number;
}

