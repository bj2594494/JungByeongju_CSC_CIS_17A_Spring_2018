/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 26, 2018, 1:02 AM
 * Purpose: Vowels and Consonants problem
 */

//System Libraries
#include <iostream>
#include <cctype>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void vowel(char *);
void cnsnant(char *);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=100;
    char array[SIZE];
    char option;
    //Input User Menu
    cout<<"This program counts number of vowels and consonants in your string."<<endl;
    cout<<"Enter your string."<<endl;
    cin.getline(array,SIZE);
    do{
        cout<<"Choose your action."<<endl;
        cout<<"A) Count the number of vowels in the string."<<endl;
        cout<<"B) Count the number of consonants in the string."<<endl;
        cout<<"C) Count both the vowels and the consonants in the string."<<endl;
        cout<<"D) Enter Another String."<<endl;
        cout<<"E) Exit the program."<<endl;
        cin>>option;
        if(option=='A'){
            vowel(array);
        }
        if(option=='B'){
            cnsnant(array);
        }
        if(option=='C'){
            vowel(array);
            cnsnant(array);
        }
        if(option=='D'){
            cout<<"Enter your string."<<endl;
            cin.ignore();
            cin.getline(array,SIZE);
        }
    }while(option!='E');
    cout<<"Exiting program..."<<endl;
    //Exit stage right!
    return 0;
}

void vowel(char *a){
    int nmVowel=0;
    while(*a != '\0'){
        if(tolower(*a) == 'a'||tolower(*a) == 'e'||tolower(*a) == 'i'||tolower(*a) == 'o'||tolower(*a) == 'u'){
            nmVowel++;
        }
        a++;
    }
    cout<<"The number of vowels in your string is "<<nmVowel<<endl;
}

void cnsnant(char *a){
    int nmCnsnt=0;
    int numWord=0;
    while(*a != '\0'){
        if(tolower(*a) != 'a'&&tolower(*a) != 'e'&&tolower(*a) != 'i'&&tolower(*a) != 'o'&&tolower(*a) != 'u'){
            nmCnsnt++;
        }
        if(*a == ' '){
            numWord++;
        }
        a++;
    }
    cout<<"The number of consonants in your string is "<<nmCnsnt-numWord<<endl;
}