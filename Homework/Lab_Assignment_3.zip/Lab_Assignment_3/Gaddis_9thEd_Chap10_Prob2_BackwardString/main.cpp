/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 11:38 PM
 * Purpose: Backward String Problem
 */

//System Libraries
#include <iostream>
#include <cstring>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void reverse(char *);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=100;
    char array[SIZE];
    //User Input
    cout<<"This program accepts and reverses string."<<endl;
    cout<<"Enter string."<<endl;
    cin.getline( array, SIZE );
    
    //Process/Map inputs to outputs
    reverse(array);
    //Output data
    
    //Exit stage right!
    return 0;
}

void reverse(char *a){
    int len = strlen(a);
    for(int i=len;i>=0;i--){
        cout<<*(a+i);
    }
}