/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 26, 2018, 7:20 PM
 * Purpose: File Display Problem
 */

//System Libraries
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=51;
    char fileNm[SIZE];
    char line[80];
    ifstream file;
    //Initialize Variables
    cout<<"This program displays strings from file."<<endl;
    cout<<"Enter the file name."<<endl;
    cin>>fileNm;
    cin.ignore();
    file.open(fileNm,ios::in);
    for(int i=1;!file.eof();i++){
        file.getline(line,80);
        cout<<i<<". "<<line<<endl;
        if(i%24==0){
            cout<<"Press any key to continue..."<<endl;
            getchar();
        }
    }
    file.close();
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}

