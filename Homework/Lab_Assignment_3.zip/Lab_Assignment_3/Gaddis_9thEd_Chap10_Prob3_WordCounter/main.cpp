/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 26, 2018, 12:20 AM
 * Purpose: Word Counter Problem
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void count(char *);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE = 100;
    char array[SIZE];
    //User Input
    cout<<"This program displays the number of words in your string."<<endl;
    cout<<"Enter your string."<<endl;
    cin.getline(array, SIZE);
    //Process/Map inputs to outputs
    cout<<"Your string has ";
    count(array);
    cout<<" words."<<endl;
    //Output data
    
    //Exit stage right!
    return 0;
}

void count(char *a){
    int numWord=1;
    while(*a != '\0'){
        if(*a == ' '){
            numWord++;
        }
        a++;
    }
    cout<<numWord;
}

