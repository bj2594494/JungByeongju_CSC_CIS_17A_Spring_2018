/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 26, 2018, 4:20 PM
 * Purpose: File Head Program Problem
 */

//System Libraries
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
bool open(fstream &, string);
void show(fstream &);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    fstream data;
    string name;
    cout<<"This program opens and reads file data."<<endl;
    cout<<"Enter file name."<<endl;
    cin>>name;
    //Process/Map inputs to outputs
    if(open(data, name)){
        cout<<"File opened successfully."<<endl;
        cout<<"Now reading data from the file."<<endl;
        show(data);
        data.close();
        cout<<"Done."<<endl;
    }
    else{
        cout<<"Error."<<endl;
    }
    
    //Exit stage right!
    return 0;
}

bool open(fstream &a, string b){
    a.open(b, ios::in);
    if(a.fail()){
        return false;
    }
    else
        return true;
}

void show(fstream &a){
    string line;
    int count=0;
    cout<<endl<<endl;
    while(getline(a, line)){
        cout<<line<<endl;
        count++;
    }
    if(count<10){
        cout<<endl;
        cout<<"The entire file has been displayed."<<endl;
    }
    cout<<endl<<endl;
}