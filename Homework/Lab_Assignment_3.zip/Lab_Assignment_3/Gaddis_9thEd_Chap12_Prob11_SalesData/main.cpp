/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 24, 2018, 10:04 PM
 * Purpose: Corporate Sales Data Problem
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <fstream>
#include "data.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void getData(Company &);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Company data1,data2,data3,data4;
    string fileNm;
    fstream data;
    //Initialize Variables
    cout<<"This program stores each division's info. to textfile."<<endl;
    getData(data1);
    getData(data2);
    getData(data3);
    getData(data4);
    //Process/Map inputs to outputs
    cout<<"Enter name of the text file you would like to store the data."<<endl;
    cin>>fileNm;
    data.open(fileNm, ios::out);
    data<<"Name: "<<data1.name<<"\r"<<endl;
    data<<"First Quarter Sales:  "<<data1.fqSales<<"\r"<<endl;
    data<<"Second Quarter Sales: "<<data1.sqSales<<"\r"<<endl;
    data<<"Third Quarter Sales:  "<<data1.tqSales<<"\r"<<endl;
    data<<"Fourth Quarter Sales: "<<data1.ftSales<<"\r"<<endl;
    data<<"\r"<<endl;
    data<<"Name: "<<data2.name<<"\r"<<endl;
    data<<"First Quarter Sales:  "<<data2.fqSales<<"\r"<<endl;
    data<<"Second Quarter Sales: "<<data2.sqSales<<"\r"<<endl;
    data<<"Third Quarter Sales:  "<<data2.tqSales<<"\r"<<endl;
    data<<"Fourth Quarter Sales: "<<data2.ftSales<<"\r"<<endl;
    data<<"\r"<<endl;
    data<<"Name: "<<data3.name<<"\r"<<endl;
    data<<"First Quarter Sales:  "<<data3.fqSales<<"\r"<<endl;
    data<<"Second Quarter Sales: "<<data3.sqSales<<"\r"<<endl;
    data<<"Third Quarter Sales:  "<<data3.tqSales<<"\r"<<endl;
    data<<"Fourth Quarter Sales: "<<data3.ftSales<<"\r"<<endl;
    data<<"\r"<<endl;
    data<<"Name: "<<data4.name<<"\r"<<endl;
    data<<"First Quarter Sales:  "<<data4.fqSales<<"\r"<<endl;
    data<<"Second Quarter Sales: "<<data4.sqSales<<"\r"<<endl;
    data<<"Third Quarter Sales:  "<<data4.tqSales<<"\r"<<endl;
    data<<"Fourth Quarter Sales: "<<data4.ftSales<<"\r"<<endl;
    data<<"\r"<<endl;
    data.close();
    //Output data
    
    //Exit stage right!
    return 0;
}

void getData(Company &a){
    cout<<"Enter the division's name (East, West, North, or South)"<<endl;
    cin>>a.name;
    cout<<"Enter the first quarter sales."<<endl;
    cin>>a.fqSales;
    while(a.fqSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the first quarter sales."<<endl;
        cin>>a.fqSales;
    }
    cout<<"Enter the second quarter sales."<<endl;
    cin>>a.sqSales;
    while(a.sqSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the second quarter sales."<<endl;
        cin>>a.sqSales;
    }
    cout<<"Enter the third quarter sales."<<endl;
    cin>>a.tqSales;
    while(a.tqSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the third quarter sales."<<endl;
        cin>>a.tqSales;
    }
    cout<<"Enter the fouth quarter sales."<<endl;
    cin>>a.ftSales;
    while(a.ftSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the fourth quarter sales."<<endl;
        cin>>a.ftSales;
    }
}
