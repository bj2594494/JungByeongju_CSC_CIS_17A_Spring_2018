/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 24, 2018, 10:04 PM
 * Purpose: Corporate Sales Data Problem
 */

#ifndef DATA_H
#define DATA_H

struct Company{
    std::string name;
    float fqSales;
    float sqSales;
    float tqSales;
    float ftSales;
};

#endif /* DATA_H */

