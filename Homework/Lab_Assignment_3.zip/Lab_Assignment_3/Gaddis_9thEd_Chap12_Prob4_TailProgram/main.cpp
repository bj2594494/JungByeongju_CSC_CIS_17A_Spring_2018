/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 26, 2018, 8:20 PM
 * Purpose: Tail Program Problem
 */

//System Libraries
#include <iostream>
#include <fstream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    char fileNm[20];
    char line[80];
    char ch;
    int count=0;
    fstream fin;
    //User Input
    cout<<"This program displays last ten lines of a file."<<endl;
    cout<<"Enter file name."<<endl;
    cin.getline(fileNm,20);
    //open file for count
    fin.open(fileNm,ios::in);
    fin.get(ch);
    //Process/Map inputs to outputs
    //counting the number of lines
    while(fin){
        if(ch=='\n'){
            count++;
        }
        fin.get(ch);
    }
    //If line is less than 10
    if(count<10){
        cout<<"All File is Displayed."<<endl;
        cout<<endl<<endl;
    }
    fin.close(); //closing the file
    fin.open(fileNm,ios::in); //opening the file for reading
    fin.get(ch);
    while(fin){
        if(ch=='\n'){
            count--;
        }
        if(count<10){
            while(fin){
                cout<<ch;
                fin.get(ch);
            }
        }
        fin.get(ch);
    }
    fin.close();
    //Output data
    
    //Exit stage right!
    return 0;
}

