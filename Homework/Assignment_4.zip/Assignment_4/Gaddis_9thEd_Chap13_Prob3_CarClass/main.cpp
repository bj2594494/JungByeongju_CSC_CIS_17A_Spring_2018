/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 5:40 PM
 * Purpose: Car Class Problem
 */

//System Libraries
#include <iostream>

#include "car.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Car car1(2016,"Honda Civic");
    //Process/Map inputs to outputs
    cout<<"This program displays car's info. and demonstrates accelerate/brake function."<<endl;
    cout<<"Car: "<<car1.gtMake()<<" "<<car1.gtYear()<<endl<<endl<<endl;
    for(int i=0;i<5;i++){
    cout<<"Accelerating ("<<i+1<<")."<<endl;
    car1.acclrt();
    cout<<"Speed: "<<car1.gtSpeed()<<" mi/h."<<endl;
    }
    cout<<endl<<endl;
    for(int i=0;i<5;i++){
    cout<<"Braking ("<<i+1<<")."<<endl;
    car1.brake();
    cout<<"Speed: "<<car1.gtSpeed()<<" mi/h."<<endl;
    }

    //Output data
    
    //Exit stage right!
    return 0;
}

