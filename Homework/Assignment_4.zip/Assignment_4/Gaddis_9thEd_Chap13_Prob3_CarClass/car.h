/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 5:40 PM
 * Purpose: Car Class Problem
 */

#ifndef CAR_H
#define CAR_H
using namespace std;

class Car{
private: 
    int yrModel;
    string make;
    int speed;
public:
    Car(int a, string b){
        yrModel=a;
        make=b;
        speed=0;
    }
    int gtYear()const{
        return yrModel;
    }
    string gtMake()const{
        return make;
    }
    int gtSpeed()const{
        return speed;
    }
    int acclrt(){
        speed+=5;
        return speed;
    }
    int brake(){
        speed-=5;
        return speed;
    }
};

#endif /* CAR_H */

