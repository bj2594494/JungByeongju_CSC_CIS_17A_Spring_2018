/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 6:50 PM
 * Purpose: Retail Item Class Problem
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include "retail item.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Item item1("Jacket",12,59.95); //Item class data number 1
    Item item2("Designer Jean",40,34.95); //Item class data number 2
    Item item3("Shirt",20,24.95); //Item class data number 3
    
    
    //Output data
    cout<<"This program displays items and their info."<<endl<<endl;
    cout<<"Item         "<<"Description          "<<"Units on Hand       "<<"Price"<<endl;
    cout<<"Item #1      "<<setw(5)<<item1.gtDesc()<<setw(23)<<item1.gtUnit()<<setw(17)<<item1.gtPrice()<<endl;
    cout<<"Item #2      "<<setw(5)<<item2.gtDesc()<<setw(16)<<item2.gtUnit()<<setw(17)<<item2.gtPrice()<<endl;
    cout<<"Item #3      "<<setw(5)<<item3.gtDesc()<<setw(24)<<item3.gtUnit()<<setw(17)<<item3.gtPrice()<<endl;
    //Exit stage right!
    return 0;
}

