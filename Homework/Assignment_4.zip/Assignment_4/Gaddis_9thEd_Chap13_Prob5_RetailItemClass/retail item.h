/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 6:50 PM
 * Purpose: Retail Item Class Problem
 */

#ifndef RETAIL_ITEM_H
#define RETAIL_ITEM_H
using namespace std;

class Item{ //class name
private:
    string descrpt; //description of the item
    int unit;       //number of unit
    float price;    //price of the item
public:
    Item(string a, int b, float c){ //constructor
        descrpt=a;
        unit=b;
        price=c;
    }
    string gtDesc(){ //get function
        return descrpt;
    }
    int gtUnit(){ //get function
        return unit;
    }
    float gtPrice(){ //get function
        return price;
    }
};

#endif /* RETAIL_ITEM_H */

