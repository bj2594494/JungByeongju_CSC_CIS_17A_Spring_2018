/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 04, 2018, 12:50 AM
 * Purpose: Date Problem
 */

#ifndef CLASS_H
#define CLASS_H
#include <iostream>
using namespace std;

class Date{
private:
    int months, days, years;
public: 
    void print();
    void setMnth(int);
    void setDay(int);
    void setYear(int);
};

void Date::setMnth(int a){
    months=a;
}

void Date::setDay(int b){
    days=b;
}

void Date::setYear(int c){
    years=c;
}

void Date::print(){
    std::string month;
    switch(months){
        case 12:month="December";break;
        case 11:month="November";break;
        case 10:month="October";break;
        case 9:month="September";break;
        case 8:month="August";break;
        case 7:month="July";break;
        case 6:month="June";break;
        case 5:month="May";break;
        case 4:month="April";break;
        case 3:month="March";break;
        case 2:month="February";break;
        case 1:month="January";break;
    }
    cout<<months<<"/"<<days<<"/"<<years<<endl;
    cout<<month<<" "<<days<<", "<<years<<endl;
    cout<<days<<" "<<month<<" "<<years<<endl;
}
#endif /* CLASS_H */

