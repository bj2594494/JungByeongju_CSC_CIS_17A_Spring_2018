/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 04, 2018, 12:50 AM
 * Purpose: Date Problem
 */

//System Libraries
#include <iostream>

#include "class.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Date dates; //Class variable for dates
    int month, day, year; 
    //Input user value
    cout<<"This Program displays date."<<endl;
    cout<<"Input month in integer number."<<endl;
    cin>>month;
    do{
        cout<<"Invalid Input"<<endl;
        cout<<"Input month in integer number."<<endl;
        cin>>month;
    }while(month<1&&month>12);
    dates.setMnth(month);
    cout<<"Input day in integer number."<<endl;
    cin>>day;
    do{
        cout<<"Invalid Input"<<endl;
        cout<<"Input day in integer number."<<endl;
        cin>>day;
    }while(day<1&&day>31);
    dates.setDay(day);
    cout<<"Input year in integer number."<<endl;
    cin>>year;
    dates.setYear(year);
    //Process/Map inputs to outputs
    dates.print();
    //Output data
    
    //Exit stage right!
    return 0;
}

