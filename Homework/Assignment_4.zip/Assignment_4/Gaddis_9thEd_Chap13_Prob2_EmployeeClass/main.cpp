/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 4:20 PM
 * Purpose: Employee Class Problem
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include "employee.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Emplyee staff1;
    Emplyee staff2;
    Emplyee staff3;
    //Initialize Variables
    staff1.setName("Susan Meyers");
    staff1.setId(47899);
    staff1.setDep("Accounting");
    staff1.setPos("Vice President");
    
    staff2.setName("Mark Jones");
    staff2.setId(39119);
    staff2.setDep("IT");
    staff2.setPos("Programmer");
    
    staff3.setName("Joy Rogers");
    staff3.setId(81774);
    staff3.setDep("Manufacturing");
    staff3.setPos("Engineer");
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program shows employee lists."<<endl<<endl;
    cout<<"Name              "<<"ID Number     "<<"Department      "<<"Position"<<endl;
    cout<<staff1.getName()<<setw(11)<<staff1.getId()<<setw(19)<<staff1.getDep()<<setw(18)<<staff1.getPos()<<endl;
    cout<<staff2.getName()<<setw(13)<<staff2.getId()<<setw(15)<<staff2.getDep()<<setw(19)<<staff2.getPos()<<endl;
    cout<<staff3.getName()<<setw(13)<<staff3.getId()<<setw(20)<<staff3.getDep()<<setw(13)<<staff3.getPos()<<endl;
    //Exit stage right!
    return 0;
}

