/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 4:20 PM
 * Purpose: Employee Class Problem
 */


#ifndef EMPLOYEE_H
#define EMPLOYEE_H
using namespace std;
class Emplyee{
private:
    string name;
    int idNum;
    string depart;
    string pstn;
public:
    Emplyee(){
        name="";
        idNum=0;
        depart="";
        pstn="";
    }
    Emplyee(string nam, int id){
        name=nam;
        idNum=id;
        depart="";
        pstn="";
    }
    Emplyee(string nam, int id, string dep, string pos){
        name=nam;
        idNum=id;
        depart=dep;
        pstn=pos;
    }
    
    void setName(string a){
        name=a;
    }
    void setId(int n){
        idNum=n;
    }
    void setDep(string b){
        depart=b;
    }
    void setPos(string c){
        pstn=c;
    }
    
    string getName()const{
        return name;
    }
    int getId()const{
        return idNum;
    }
    string getDep()const{
        return depart;
    }
    string getPos()const{
        return pstn;
    }
};

#endif /* EMPLOYEE_H */

