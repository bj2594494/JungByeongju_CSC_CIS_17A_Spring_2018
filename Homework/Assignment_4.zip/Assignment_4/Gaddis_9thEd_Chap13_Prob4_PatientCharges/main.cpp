/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 6:05 PM
 * Purpose: Patient Charges
 */

//System Libraries
#include <iostream>

#include "patient.h"
#include "procedure.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Patient pat("Danny","Lee","Jung","4800 Magnolia Ave","Riverside","CA",92508,
            1234567890,"Theresa Jung",1234321234);
    Procdre pro1("Physical Exam","April 4th 2018","Dr. Irvine", 250.00);
    Procdre pro2("X-ray","April 4th 2018","Dr. Jamison", 500.00);
    Procdre pro3("Blood test","April 4th 2018","Dr. Smith", 200.00);
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program displays patients info., and the medical procedures."<<endl;
    cout<<"First Name:   "<<pat.gtFName()<<endl;
    cout<<"Middle Name:  "<<pat.gtMName()<<endl;
    cout<<"Last Name:    "<<pat.gtLName()<<endl;
    cout<<"Address:      "<<pat.gtAdd()<<endl;
    cout<<"City:         "<<pat.gtCity()<<endl;
    cout<<"State:        "<<pat.gtState()<<endl;
    cout<<"Zip Code:     "<<pat.getZip()<<endl;
    cout<<"Phone Number: "<<pat.gtPhone()<<endl;
    cout<<"Emergency:    "<<pat.gtEName()<<endl;
    cout<<"Phone Number: "<<pat.gEPhone()<<endl<<endl;
    
    cout<<"Procedure #1:"<<endl;
    cout<<"Procedure Name: "<<pro1.gtName()<<endl;
    cout<<"Date:           "<<pro1.gtDate()<<endl;
    cout<<"Practitional:   "<<pro1.gtDoc()<<endl;
    cout<<"Charge:          $"<<pro1.gtCharg()<<".00"<<endl<<endl;
    
    cout<<"Procedure #2:"<<endl;
    cout<<"Procedure Name: "<<pro2.gtName()<<endl;
    cout<<"Date:           "<<pro2.gtDate()<<endl;
    cout<<"Practitional:   "<<pro2.gtDoc()<<endl;
    cout<<"Charge:          $"<<pro2.gtCharg()<<".00"<<endl<<endl;
    
    cout<<"Procedure #3:"<<endl;
    cout<<"Procedure Name: "<<pro3.gtName()<<endl;
    cout<<"Date:           "<<pro3.gtDate()<<endl;
    cout<<"Practitional:   "<<pro3.gtDoc()<<endl;
    cout<<"Charge:          $"<<pro3.gtCharg()<<".00"<<endl<<endl;
    
    //Exit stage right!
    return 0;
}

