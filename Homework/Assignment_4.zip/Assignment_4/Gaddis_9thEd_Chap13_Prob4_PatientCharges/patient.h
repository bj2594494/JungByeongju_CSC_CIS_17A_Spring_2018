/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 6:05 PM
 * Purpose: Patient Charges
 */

#ifndef PATIENT_H
#define PATIENT_H
using namespace std;

class Patient{
private:
    string fstName;
    string mdName;
    string lstName;
    string address;
    string city;
    string state;
    int zip;
    unsigned long phone;
    string emName;
    unsigned long emPhone;
public:
    Patient(string fst, string md, string lst, string add, string ct,
            string st,int zp,unsigned long ph, string emN, unsigned long emP){
        fstName=fst;
        mdName=md;
        lstName=lst;
        address=add;
        city=ct;
        state=st;
        zip=zp;
        phone=ph;
        emName=emN;
        emPhone=emP;
    }
    string gtFName(){
        return fstName;
    }
    string gtMName(){
        return mdName;
    }
    string gtLName(){
        return lstName;
    }
    string gtAdd(){
        return address;
    }
    string gtCity(){
        return city;
    }
    string gtState(){
        return state;
    }
    string gtEName(){
        return emName;
    }
    int getZip(){
        return zip;
    }
    unsigned long gtPhone(){
        return phone;
    }
    unsigned long gEPhone(){
        return emPhone;
    }
};

#endif /* PATIENT_H */

