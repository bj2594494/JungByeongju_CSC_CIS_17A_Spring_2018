/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 6:05 PM
 * Purpose: Patient Charges
 */

#ifndef PROCEDURE_H
#define PROCEDURE_H
using namespace std;

class Procdre{
private:
    string name;
    string date;
    string doctor;
    float charge;
public:
    Procdre(string nm, string dt, string dc, float ch){
        name=nm;
        date=dt;
        doctor=dc;
        charge=ch;
    }
    string gtName(){
        return name;
    }
    string gtDate(){
        return date;
    }
    string gtDoc(){
        return doctor;
    }
    float gtCharg(){
        return charge;
    }
};

#endif /* PROCEDURE_H */

