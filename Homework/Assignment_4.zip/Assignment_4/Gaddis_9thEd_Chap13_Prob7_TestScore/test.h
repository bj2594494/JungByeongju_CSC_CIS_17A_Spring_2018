/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 7:09 PM
 * Purpose: Test Score Problem
 */

#ifndef TEST_H
#define TEST_H

class Test{
private:
    float score1;
    float score2;
    float score3;
public:
    Test(){
        score1=0;
        score2=0;
        score3=0;
    }
    void stScr1(float s1){
        score1=s1;
    }
    void stScr2(float s2){
        score2=s2;
    }
    void stScr3(float s3){
        score3=s3;
    }
    float gtScr1(){
        return score1;
    }
    float gtScr2(){
        return score2;
    }
    float gtScr3(){
        return score3;
    }
    float avgScr(){
        float average=(score1+score2+score3)/3;
        return average;
    }
};

#endif /* TEST_H */

