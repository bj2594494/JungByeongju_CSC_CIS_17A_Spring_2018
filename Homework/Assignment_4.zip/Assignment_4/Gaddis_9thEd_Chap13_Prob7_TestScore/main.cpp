/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 4, 2018, 7:09 PM
 * Purpose: Test Score Problem
 */

//System Libraries
#include <iostream>

#include "test.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Test test1;
    float score1, score2,score3,average;
    //Input Value
    cout<<"This program stores three tests and calculates average."<<endl;
    cout<<"Enter the score of the first test."<<endl;
    cin>>score1;
    test1.stScr1(score1);
    cout<<"Enter the score of the second test."<<endl;
    cin>>score2;
    test1.stScr2(score2);
    cout<<"Enter the score of the third test."<<endl;
    cin>>score3;
    test1.stScr3(score3);
    //Process/Map inputs to outputs
    average=test1.avgScr();
    //Output data
    cout<<endl<<endl;
    cout<<"First  Test: "<<test1.gtScr1()<<endl;
    cout<<"Second Test: "<<test1.gtScr2()<<endl;
    cout<<"Thrid  Test: "<<test1.gtScr3()<<endl;
    cout<<"Average    : "<<average<<endl;
    //Exit stage right!
    return 0;
}

