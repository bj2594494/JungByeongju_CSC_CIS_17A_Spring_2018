/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr and Byeongju Jung
 * Created on February 28, 2018, 1:22 PM
 * Purpose:  Dynamic 2-D Array
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>   //srand, rand
#include <ctime>     //Time
using namespace std;

//User Libraries

//Global Constants - Math, Science, Conversions, 2D Array Sizes
const int COLSMAX=20;//Maximum Columns in a 2-D Array
//Function Prototypes
void  fillAry(int [][COLSMAX],int,int);
void  prntAry(int [][COLSMAX],int,int);

//Executions Begin Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare and allocate memory for the array
    const int ROWSMAX=10;
    int array[ROWSMAX][COLSMAX];
    
    //Fill the array
    fillAry(array,ROWSMAX,COLSMAX);
    //Print the random 2-Digit array
    prntAry(array,ROWSMAX,COLSMAX);
    
    return 0;
}

void  prntAry(int array[][COLSMAX],int rows,int cols){
    cout<<endl;
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            cout<<array[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}

void  fillAry(int array[][COLSMAX],int rows,int cols){
    for(int i=0;i<rows;i++){
        for(int j=0;j<cols;j++){
            array[i][j]=rand()%90+10;//[10,99]
        }
    }
}
