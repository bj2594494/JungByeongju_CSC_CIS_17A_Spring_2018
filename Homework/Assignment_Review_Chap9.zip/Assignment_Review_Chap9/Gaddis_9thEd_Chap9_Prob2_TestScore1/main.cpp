/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 13, 2018, 10:14 PM
 * Purpose: Test Score 1
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void sort(int *, int);
float average(int *, int);
void print(int *, int);
void destroy(int*);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int *scores=nullptr;
    int numTest,
        avScore;
    //User Input
    cout<<"This program sorts and calculates average test score."<<endl;
    cout<<"Please enter the amount of tests you wish to calculate."<<endl;
    cin>>numTest;
    
    //Process/Map inputs to outputs
    scores=new int[numTest];
    cout<<"Enter each test scores one by one."<<endl;
    for(int i=0;i<numTest;i++){
        cout<<"Test "<<i+1<<" = ";
        cin>>scores[i];
        if(scores[i]<0){
            cout<<"Invalid Entry"<<endl;
            cout<<"Test "<<i+1<<" = ";
            cin>>scores[i];
        }
    }
    
    sort(scores, numTest);
    avScore=average(scores, numTest);
    //Output data
    cout<<"Sorted Test Scores:"<<endl;
    print(scores, numTest);
    cout<<"The Average Score = "<<avScore<<endl;
    
    destroy(scores);
    //Exit stage right!
    return 0;
}

void sort(int *array, int size){
    bool swap;
    char temp;
    do{
        swap=false;
        for(int i=0;i<(size-1);i++){
            if (*(array+i)>*(array+(i+1))){
                temp=*(array+i);
                *(array+i)=*(array+(i+1));
                *(array+(i+1))=temp;
                swap=true;
            }
        }
    }while(swap);
}

float average(int *array,int size){
    int total=0;
    float average;
    for(int i=0;i<size;i++){
        total+=*(array+i);
    }
    average=total/size;
    return average;
}

void print(int *array, int size){
    for(int i=0;i<size;i++){
        cout<<*(array+i)<<" ";
    }
    cout<<endl;
}

void destroy(int *a){
    if(!a){
        delete []a;
    }
}