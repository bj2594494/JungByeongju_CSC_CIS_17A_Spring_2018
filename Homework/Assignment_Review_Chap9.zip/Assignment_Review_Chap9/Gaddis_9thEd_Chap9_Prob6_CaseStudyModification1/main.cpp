/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 13, 2018, 11:04 PM
 * Purpose: Modifying Case Study1
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void sort(int *,int);
void show(int *,int);
void destroy(int*);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int *donate=nullptr;
    int *arrPtr=nullptr;
    int numVal;
    //User Input
    cout<<"This program sorts and calculates average test score."<<endl;
    cout<<"Please enter the number of donations received."<<endl;
    cin>>numVal;
    
    //Process/Map inputs to outputs
    donate=new int[numVal];
    arrPtr=new int[numVal];
    cout<<"Enter each donation one by one."<<endl;
    for(int i=0;i<numVal;i++){
        cout<<"Donation "<<i+1<<" = ";
        cin>>donate[i];
    }
    for(int i=0;i<numVal;i++){
        arrPtr[i]=donate[i];
    }
    sort(arrPtr, numVal);
    //Output data
    cout<<"The donations in acsending order are:"<<endl;
    show(arrPtr, numVal);
    cout<<"The donations in orginal order are:"<<endl;
    show(donate, numVal);
    destroy(arrPtr);
    destroy(donate);
    //Exit stage right!
    return 0;
}

void sort(int *array,int size){
    bool swap;
    char temp;
    do{
        swap=false;
        for(int i=0;i<(size-1);i++){
            if (*(array+i)>*(array+(i+1))){
                temp=*(array+i);
                *(array+i)=*(array+(i+1));
                *(array+(i+1))=temp;
                swap=true;
            }
        }
    }while(swap);
}

void show(int *array, int size){
     for(int i=0;i<size;i++){
        cout<<*(array+i)<<" ";
    }
    cout<<endl;
}

void destroy(int *a){
    if(!a){
        delete []a;
    }
}