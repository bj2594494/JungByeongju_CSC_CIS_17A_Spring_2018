/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 13, 2018, 11:30 PM
 * Purpose: Calculate Average, Mode, Median
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void sort(int [],int,int &);
void medianf(int[],int ,int &);
void modef(int[]);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int SIZE=80;
    int array[SIZE];
    int sizeIn;
    int average,
         median;
    //Input Values
    cout<<"This program calculates mean,median and mode(Was not able to program mode)."<<endl;
    cout<<"Please input the array size less than 20."<<endl;
    cin>>sizeIn;
    
    cout<<"Please input values into the array"<<endl;
    for(int i=0;i<sizeIn;i++){
        cin>>array[i];
    }
    
    //Process/Map inputs to outputs
    sort(array,sizeIn,average);
    //Output data
    cout<<"The average = "<<average<<"."<<endl;
    cout<<"The  median = "<<median<<"."<<endl;
    cout<<"Was not able to program mode."<<endl;
    //Exit stage right!
    return 0;
}

void sort(int array[],int size,int &average){
    bool swap;
    int temp;
    int total=0;
    do{
        swap=false;
        for(int i=0;i<(size-1);i++){
            if (array[i]>array[i+1]){
                temp=array[i+1];
                array[i]=array[i+1];
                array[i+1]=temp;
                swap=true;
            }
        }
    }while(swap);
    for(int j=0;j<size;j++){
        total+=array[j];
    }
    average=total/size;
}

void medianf(int array[],int size, int &median){
    int middle;
    if(size%2==1){
        middle=(size/2)+1;
        median=array[middle];
    }
    else if(size%2==0){
        middle=size/2;
        median=(array[middle]+array[middle+1])/2;
    }
}

