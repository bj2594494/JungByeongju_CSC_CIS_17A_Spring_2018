/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 24, 2018, 10:57 PM
 * Purpose: Weather Statistics Problem
 */

#ifndef DATA_H
#define DATA_H

enum Month {January, February, March, April, May, June, July, August, 
    September, October, November, December};

struct Weather{
    float total;
    float highTem;
    float lowTem;
    float avTem;
};

#endif /* DATA_H */

