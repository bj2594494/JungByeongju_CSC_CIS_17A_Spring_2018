/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 24, 2018, 10:57 PM
 * Purpose: Weather Statistics Problem
 */

//System Libraries
#include <iostream>

#include "data.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void getData(Weather []);
void stats(Weather [],float &, float &, float &, float &, float &);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int NUMBER=12;
    Weather month[NUMBER];
    float hiTemp, lowTemp, avRain, ttlRain, avgTemp;
    //Initialize Variables
    ttlRain=0;
    getData(month);
    //Process/Map inputs to outputs
    stats(month,hiTemp,lowTemp,avRain,ttlRain,avgTemp);
    //Output data
    cout<<endl<<endl;
    cout<<"Total Rainfall      = "<<ttlRain<<" inches"<<endl;
    cout<<"Average Rainfall    = "<<avRain<<" inches"<<endl;
    cout<<"Highest Temperature = "<<hiTemp<<" Fahreheit"<<endl;
    cout<<"Lowest Temperature  = "<<lowTemp<<" Fahreheit"<<endl;
    cout<<"Average Temperature = "<<avgTemp<<" Fahreheit"<<endl;
    
    
    //Exit stage right!
    return 0;
}

void getData(Weather a[]){
    cout<<"This program Stores the weather data for year."<<endl;
    for(Month i=January;i<=December;i=static_cast<Month>(i+1)){
        cout<<"Data for month "<<i+1<<"."<<endl;
        cout<<"Enter the total rainfall(inch) for month "<<i+1<<"."<<endl;
        cin>>a[i].total;
        cout<<"Enter the highest temperature(Fahreheit) for month "<<i+1<<"."<<endl;
        cout<<"Enter temperature between -100 and 140."<<endl;
        cin>>a[i].highTem;
        cout<<"Enter the lowest temperature(Fahreheit) for month "<<i+1<<"."<<endl;
        cout<<"Enter temperature between -100 and 140."<<endl;
        cin>>a[i].lowTem;
        a[i].avTem=(a[i].highTem+a[i].lowTem)/2;
    }
}

void stats(Weather a[],float &hiTemp, float &lowTemp, float &avRain, float &ttlRain, float &avgTemp){
    float sumTemp=0;
    bool counter=false;
    hiTemp=0;
    lowTemp=140;
    for(Month i=January;i<=December;i=static_cast<Month>(i+1)){
        ttlRain+=a[i].total;
        sumTemp+=a[i].avTem;
        if(a[i].highTem>hiTemp){
            hiTemp=a[i].highTem;
        }
        if(a[i].lowTem<lowTemp){
            lowTemp=a[i].lowTem;
        }
    }
    avRain=ttlRain/12;
    avgTemp=sumTemp/12;
}