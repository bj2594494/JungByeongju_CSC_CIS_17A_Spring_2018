/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 10:02 PM
 * Purpose: Customer Accounts Problem
 */

//System Libraries
#include <iostream>
#include "data.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void enter(Account []);
void change(Account []);
void display(Account []);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int NUMBER=10;
    Account array[NUMBER];
    int option;
    //User Input
    do{
        cout<<"This program stores customer accounts information."<<endl;
        cout<<"Enter the number for desired action."<<endl;
        cout<<"1. Enter Accounts."<<endl;
        cout<<"2. Make Changes to Account Info."<<endl;
        cout<<"3. See All Account Info."<<endl;
        cout<<"4. End the Program."<<endl;
        cin>>option;

        if(option==1){
            enter(array);
        }
        if(option==2){
            change(array);
        }
        if(option==3){
            display(array);
        }
    }while(option!=4);
    cout<<"Exiting the program..."<<endl;
    //Exit stage right!
    return 0;
}

void enter(Account a[]){
    cin.ignore();
    for(int i=0;i<10;i++){
        cout<<"Enter the name of the Account "<<i+1<<endl;
        getline(cin,a[i].name);
        cout<<"Enter the address of the Account "<<i+1<<endl;
        getline(cin,a[i].address);
        cout<<"Enter the City, State, ZIP of the Account "<<i+1<<endl;
        getline(cin,a[i].addrss2);
        cout<<"Enter the phone number of the Account "<<i+1<<endl;
        cout<<"No Dash, Just Number"<<endl;
        cin>>a[i].number;
        cout<<"Enter the balance of the Account "<<i+1<<endl;
        cin>>a[i].balance;
        cout<<"Enter the date of last payment for the Account "<<i+1<<endl;
        cout<<"ex. March 25, 2018 -> 032518"<<endl;
        cin>>a[i].date;
        cin.ignore();
    }
}

void change(Account a[]){
    int i;
    cout<<"Enter the account number (1-10) of the account you like to change."
            <<endl;
    cin>>i;
    cin.ignore();
    cout<<"Enter the name of the Account "<<i<<endl;
    getline(cin,a[i-1].name);
    cout<<"Enter the address of the Account "<<i<<endl;
    getline(cin,a[i-1].address);
    cout<<"Enter the City, State, ZIP of the Account "<<i<<endl;
    getline(cin,a[i-1].addrss2);
    cout<<"Enter the phone number of the Account "<<i<<endl;
    cout<<"No Dash, Just Number"<<endl;
    cin>>a[i-1].number;
    cout<<"Enter the balance of the Account "<<i<<endl;
    cin>>a[i-1].balance;
    cout<<"Enter the date of last payment for the Account "<<i<<endl;
    cout<<"ex. March 25, 2018 -> 032518"<<endl;
    cin>>a[i-1].date;
}

void display(Account a[]){
    cout<<endl<<endl;
    for(int i=0;i<10;i++){
       cout<<a[i].name<<"   "<<a[i].address<<" "<<a[i].addrss2<<endl;
       cout<<"Phone Number = "<<a[i].number<<endl;
       cout<<"Balance = $"<<a[i].balance<<endl;
       cout<<"Date = "<<a[i].date<<endl;
    }
    cout<<endl;
    cout<<endl;
}