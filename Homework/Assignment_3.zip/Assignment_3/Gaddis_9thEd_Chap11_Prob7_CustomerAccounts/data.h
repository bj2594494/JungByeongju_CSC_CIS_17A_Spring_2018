/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 10:02 PM
 * Purpose: Customer Accounts Problem
 */

#ifndef DATA_H
#define DATA_H

struct Account{
    std::string name;
    std::string address;
    std::string addrss2;
    unsigned long number;
    unsigned long balance;
    unsigned long date;
};

#endif /* DATA_H */

