/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 9067 PM
 * Purpose: Soccer Score Problem
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include "data.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void getData(Player []);
unsigned short stats(Player []);
void mvp(Player []);
void display(Player [], unsigned short);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int NUMBER=12;
    Player play[NUMBER];
    unsigned short tlPoint;
    //Initialize Variables
    getData(play);
    //Process/Map inputs to outputs
    tlPoint=stats(play);
    //Output data
    display(play, tlPoint);
    mvp(play);
    
    //Exit stage right!
    return 0;
}

void getData(Player a[]){
    cout<<"This program stores the player data."<<endl;
    for(int i=0;i<12;i++){
        cout<<"Enter Player "<<i+1<<"'s name."<<endl;
        getline( cin, a[i].name );
        cout<<"Enter Player "<<i+1<<"'s number."<<endl;
        cin>>a[i].number;
        cout<<"Enter Player "<<i+1<<"'s points scored."<<endl;
        cin>>a[i].score;
        cin.ignore();
    }
}

unsigned short stats(Player a[]){
    unsigned short tlPoint=0;
    for(int i=0;i<12;i++){
        tlPoint+=a[i].score;
    }
    return tlPoint;
}

void mvp(Player a[]){
    int mvpCntr;
    int counter=0;
    for(int i=0;i<12;i++){
        if(a[i].score>counter){
            counter=a[i].score;
            mvpCntr=i;
        }
    }
    cout<<"The most scored player of the team = "
            <<a[mvpCntr].name<<", "<<"Number "<<a[mvpCntr].number<<"."<<endl;
    
}

void display(Player a[], unsigned short t){
    for(int i=0;i<12;i++){
        cout<<setw(12)<<a[i].name<<setw(3)<<a[i].number<<setw(4)<<a[i].score<<endl;
    }
    cout<<"Total points scored bt the team = "<<t<<"."<<endl;
}