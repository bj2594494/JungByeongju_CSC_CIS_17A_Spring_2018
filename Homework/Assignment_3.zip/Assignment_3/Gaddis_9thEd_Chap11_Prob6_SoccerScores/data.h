/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 9067 PM
 * Purpose: Soccer Score Problem
 */

#ifndef DATA_H
#define DATA_H

struct Player{
    std::string name;
    unsigned short number;
    unsigned short score;
};

#endif /* DATA_H */

