/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 24, 2018, 10:04 PM
 * Purpose: Corporate Sales Data Problem
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include "data.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void getData(Company &);
void display(Company);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    Company data1,data2,data3,data4;
    //Initialize Variables
    cout<<"This program stores and displays each division's info."<<endl;
    getData(data1);
    getData(data2);
    getData(data3);
    getData(data4);
    //Process/Map inputs to outputs
    display(data1);
    display(data2);
    display(data3);
    display(data4);
    //Output data
    
    //Exit stage right!
    return 0;
}

void getData(Company &a){
    cout<<"Enter the division's name (East, West, North, or South)"<<endl;
    cin>>a.name;
    cout<<"Enter the first quarter sales."<<endl;
    cin>>a.fqSales;
    while(a.fqSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the first quarter sales."<<endl;
        cin>>a.fqSales;
    }
    cout<<"Enter the second quarter sales."<<endl;
    cin>>a.sqSales;
    while(a.sqSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the second quarter sales."<<endl;
        cin>>a.sqSales;
    }
    cout<<"Enter the third quarter sales."<<endl;
    cin>>a.tqSales;
    while(a.tqSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the third quarter sales."<<endl;
        cin>>a.tqSales;
    }
    cout<<"Enter the fouth quarter sales."<<endl;
    cin>>a.ftSales;
    while(a.ftSales<0){
        cout<<"Invalid Entry"<<endl;
        cout<<"Enter the fourth quarter sales."<<endl;
        cin>>a.ftSales;
    }
    a.tlSales=a.fqSales+a.sqSales+a.tqSales+a.ftSales;
    a.avSales=a.tlSales/4;
}

void display(Company a){
    cout<<endl<<endl;
    cout<<fixed<<setprecision(2);
    cout<<"Division Name: "<<a.name<<endl;
    cout<<"First Quarter Sales:  $"<<a.fqSales<<endl;
    cout<<"Second Quarter Sales: $"<<a.sqSales<<endl;
    cout<<"Third Quarter Sales:  $"<<a.tqSales<<endl;
    cout<<"Fourth Quarter Sales: $"<<a.ftSales<<endl;    
    cout<<"The Total Sales:      $"<<a.tlSales<<endl;
    cout<<"The Average Sales:    $"<<a.avSales<<endl;
}