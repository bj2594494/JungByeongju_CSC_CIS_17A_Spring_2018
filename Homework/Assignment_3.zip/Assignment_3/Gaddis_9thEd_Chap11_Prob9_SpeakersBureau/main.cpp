/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 10:58 PM
 * Purpose: Speakers' Bureau Problem
 */

//System Libraries
#include <iostream>
#include "data.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void enter(Account []);
void change(Account []);
void display(Account []);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int NUMBER=10;
    Account array[NUMBER];
    int option;
    //User Input
    do{
        cout<<"This program stores speakers' information."<<endl;
        cout<<"Enter the number for desired action."<<endl;
        cout<<"1. Enter All Speakers' Info."<<endl;
        cout<<"2. Make Changes to Info."<<endl;
        cout<<"3. See All Speakers' Info."<<endl;
        cout<<"4. End the Program."<<endl;
        cin>>option;

        if(option==1){
            enter(array);
        }
        if(option==2){
            change(array);
        }
        if(option==3){
            display(array);
        }
    }while(option!=4);
    cout<<"Exiting the program..."<<endl;
    //Exit stage right!
    return 0;
}

void enter(Account a[]){
    cin.ignore();
    for(int i=0;i<10;i++){
        cout<<"Enter the name of the Speaker "<<i+1<<endl;
        getline(cin,a[i].name);
        cout<<"Enter the topic of Speaker "<<i+1<<endl;
        getline(cin,a[i].topic);
        cout<<"Enter the phone number of the Speaker "<<i+1<<endl;
        cout<<"No Dash, Just Number"<<endl;
        cin>>a[i].number;
        cout<<"Enter the fee required by Speaker "<<i+1<<endl;
        cin>>a[i].fee;
        cin.ignore();
    }
}

void change(Account a[]){
    int i;
    cout<<"Enter the account number (1-10) of the account you like to change."
            <<endl;
    cin>>i;
    cin.ignore();
    cout<<"Enter the name of the Speaker "<<i<<endl;
        getline(cin,a[i-1].name);
        cout<<"Enter the topic of Speaker "<<i<<endl;
        getline(cin,a[i-1].topic);
        cout<<"Enter the phone number of the Speaker "<<i<<endl;
        cout<<"No Dash, Just Number"<<endl;
        cin>>a[i-1].number;
        cout<<"Enter the fee required by Speaker "<<i<<endl;
        cin>>a[i-1].fee;
}

void display(Account a[]){
    cout<<endl<<endl;
    for(int i=0;i<10;i++){
       cout<<a[i].name<<endl;
       cout<<"Phone Number : "<<a[i].number<<endl;
       cout<<"Topic : "<<a[i].topic<<endl;
       cout<<"Fee Required : "<<a[i].fee<<endl;
       cout<<endl<<endl;
    }
    cout<<endl;
    cout<<endl;
}