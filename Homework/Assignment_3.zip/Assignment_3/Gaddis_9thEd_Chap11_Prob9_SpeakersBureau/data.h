/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 25, 2018, 10:02 PM
 * Purpose: Customer Accounts Problem
 */

#ifndef DATA_H
#define DATA_H

struct Account{
    std::string name;
    unsigned long number;
    std::string topic;
    unsigned long fee;
};

#endif /* DATA_H */

