/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 24, 2018, 9:50 PM
 * Purpose: Movie Profit Program
 */

//System Libraries
#include <iostream>

#include "mvData.h"
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototype
void getData(MvData &); //Function for getting the movie data
void display(MvData, MvData);    //Function that displays the data
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    MvData movie1, movie2; //Two struct variables that holds the movie data
    //Initialize Variables
    cout<<"This program holds and displays two movie data."<<endl;
    cout<<"Data for the first movie."<<endl;
    getData(movie1);
    cout<<"Data for the second movie."<<endl;
    getData(movie2);
    //Output data
    display(movie1,movie2);
    //Exit stage right!
    return 0;
}

void getData(MvData &a){
    cout<<"Enter the title of movie."<<endl;
    getline(cin, a.title);
    cout<<"Enter the director of movie."<<endl;
    getline(cin, a.drctr);
    cout<<"Enter the year the movie was released."<<endl;
    cin>>a.year;
    cout<<"Enter the running time of movie in minutes."<<endl;
    cin>>a.time;
    cout<<"Enter the production costs of the movie."<<endl;
    cin>>a.costs;
    cout<<"Enter the first year revenues of the movie."<<endl;
    cin>>a.revenue;
    cin.ignore();
}

void display(MvData a, MvData b){
    cout<<endl<<endl;
    cout<<"Title of movie 1:               "<<a.title<<endl;
    cout<<"Director of movie 1:            "<<a.drctr<<endl;
    cout<<"Year the movie 1 was released : "<<a.year<<endl;
    cout<<"Running time of movie 1:        "<<a.time<<endl;
    if(a.revenue-a.costs>0){
        cout<<"The profit was $"<<a.revenue-a.costs<<endl;
    }
    else if (a.revenue-a.costs<0){
        cout<<"The loss was $"<<a.revenue-a.costs<<endl;
    }
    else {
        cout<<"There were no profit or loss."<<endl;
    }
    cout<<endl<<endl;
    cout<<"Title of movie 2:               "<<b.title<<endl;
    cout<<"Director of movie 2:            "<<b.drctr<<endl;
    cout<<"Year the movie 2 was released : "<<b.year<<endl;
    cout<<"Running time of movie 2:        "<<b.time<<endl;
    if(b.revenue-b.costs>0){
        cout<<"The profit was $"<<b.revenue-b.costs<<endl;
    }
    else if (b.revenue-b.costs<0){
        cout<<"The loss was $"<<b.revenue-b.costs<<endl;
    }
    else {
        cout<<"There were no profit or loss."<<endl;
    }
}