/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on March 22, 2018, 8:20 PM
 * Purpose: Movie Data Program
 */

#ifndef MVDATA_H
#define MVDATA_H
#include <string>

struct MvData{
    std::string title;
    std::string drctr;
    unsigned short year;
    unsigned short time;
    unsigned long costs;
    unsigned long revenue;
    
};


#endif /* MVDATA_H */

