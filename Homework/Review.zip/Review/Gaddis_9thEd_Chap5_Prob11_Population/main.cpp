/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 28, 2018, 12:09 AM
 * Purpose: Population
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float popSize,//Size of population
          number, //Starting number of organism
          days,   //Number of days
          incrs,  //actual increase of population
          popIncr;//Daily population increase in percent
    //User Input and initialize variables
    cout<<"This program calculates population increase of organisms."<<endl;
    cout<<"Please enter the starting number of organism."<<endl;
    cout<<"Do not enter a value less than 2."<<endl;
    cin>>number;
    while(number<2){ //User validation
    cout<<"Please enter the starting number of organism."<<endl;
    cout<<"Do not enter a value less than 2"<<endl;
    cin>>number;
    }
    
    cout<<"Please enter the number of days the organism will multiply."<<endl;
    cout<<"Do not enter a value less than 1."<<endl;
    cin>>days;
    while(days<1){ //User validation
    cout<<"Please enter the number of days the organism will multiply."<<endl;
    cout<<"Do not enter a value less than 1."<<endl;
    cin>>days;
    }
    
    cout<<"Please enter the average daily population"
            " increase of the organisms in percent."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>popIncr;
    while(popIncr<0){ //User validation
    cout<<"Please enter the average daily population"
            " increase of the organisms in percent."<<endl;
    cout<<"Do not enter a negative value."<<endl;
    cin>>popIncr;
    }
    popSize=number;
    //Process/Map inputs to outputs
    cout<<endl<<"Day    Population Size"<<endl;
    cout<<"----------------------"<<endl;
    cout<<fixed<<setprecision(0);
    for (int i=0;i<days;i++){
        if(i>0){
            incrs=popSize*(popIncr*.01);
            popSize+=incrs;
            cout<<"Day "<<i+1<<" "<<setw(9)<<popSize<<endl;
        }
        else cout<<"Day "<<i+1<<" "<<setw(9)<<popSize<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

