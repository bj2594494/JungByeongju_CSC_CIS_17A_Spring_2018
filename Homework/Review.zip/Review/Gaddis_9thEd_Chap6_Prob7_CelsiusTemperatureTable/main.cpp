/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 28, 2018, 5:00 PM
 * Purpose: Celsius Temperature Table
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
float celsius(float );
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    cout<<"This program creates a table that shows 0~20 Fahrenheit temperatures"
            <<" and their celsius equivalents."<<endl;
    for(float i=0;i<=20;i++){
        float cel=celsius(i);
        cout<<fixed<<setprecision(0);
        cout<<setw(3)<<i<<" Fahrenheit = ";
        cout<<fixed<<setprecision(1);
        cout<<setw(5)<<cel<<" celsius."<<endl;
    }
    //Output data
    
    //Exit stage right!
    return 0;
}

float celsius(float degree){
    float cel;
    cel=(5.0/9.0)*(degree-32);
    return cel;
}