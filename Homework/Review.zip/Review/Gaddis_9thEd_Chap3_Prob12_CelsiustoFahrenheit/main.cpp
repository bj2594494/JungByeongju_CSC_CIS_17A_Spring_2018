/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 27, 2018, 7:43 PM
 * Purpose: Converting Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float celsius, //User input for celsius temperature
        farnhit; //Output value in fahrenheit
    //User input
    cout<<"This program converts celsius temperature"
            <<" to fahrenheit temperature."<<endl;
    cout<<"Please enter the temperature in celsius."<<endl;
    cin>>celsius;
    
    //Process/Map inputs to outputs
    farnhit=((1.8)*celsius)+32;
    //Output data
    cout<<fixed<<setprecision(2);
    cout<<celsius<<" celsisus = "<<farnhit<<" Fahrenheit."<<endl;
    //Exit stage right!
    return 0;
}

