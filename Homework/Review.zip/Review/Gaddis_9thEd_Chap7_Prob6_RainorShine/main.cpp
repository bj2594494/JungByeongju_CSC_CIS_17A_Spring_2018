/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 28, 2018, 5:34 PM
 * Purpose: Rain or Shine Problem
 */

//System Libraries

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions
const int COLSMAX=30;//Maximum Columns in a 2-D Array
//Function Prototypes
void  fillAry(char [][COLSMAX]);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    const int ROWSMAX=3;
    char weather[ROWSMAX][COLSMAX];
    int  rainA,
         sunnyA,
         cloudA,
         rainB,
         sunnyB,
         cloudB,
         rainC,
         sunnyC,
         cloudC,
         grRain;
    
    //Initialize Variables
    rainA=0;
    sunnyA=0;
    cloudA=0;
    rainB=0;
    sunnyB=0;
    cloudB=0;
    rainC=0;
    sunnyC=0;
    cloudC=0;
    //Process/Map inputs to outputs
    
    //Fill the array
    fillAry(weather);
    //Output data
    for(int i=0;i<COLSMAX;i++){
        weather[0][i];
        if(weather[0][i]=='S'){
            sunnyA++;
        }
        if(weather[0][i]=='R'){
            rainA++;
        }
        if(weather[0][i]=='C'){
            cloudA++;
        }
    }
    for(int j=0;j<COLSMAX;j++){
        weather[1][j];
        if(weather[1][j]=='S'){
            sunnyB++;
        }
        if(weather[1][j]=='R'){
            rainB++;
        }
        if(weather[1][j]=='C'){
            cloudB++;
        }
    }
    for(int k=0;k<COLSMAX;k++){
        weather[2][k];
        if(weather[2][k]=='S'){
            sunnyC++;
        }
        if(weather[2][k]=='R'){
            rainC++;
        }
        if(weather[2][k]=='C'){
            cloudC++;
        }
    }
    if((rainA>rainB)&&(rainA>rainC)){
        grRain=1;
    }
    else if((rainB>rainA)&&(rainB>rainC)){
        grRain=2;
    }
    else if((rainC>rainB)&&(rainC>rainA)){
        grRain=3;
    }
    else if (rainA==rainB&&rainA==rainC){
        grRain=0;
    }
    cout<<"This program displays the weather for three months."<<endl;
    cout<<"In June, there were:"<<endl;
    cout<<"      "<<setw(2)<<sunnyA<<" Sunny  Days."<<endl;
    cout<<"      "<<setw(2)<<rainA<<" Rainy  Days."<<endl;
    cout<<"      "<<setw(2)<<cloudA<<" Cloudy Days."<<endl;
    cout<<"In July, there were:"<<endl;
    cout<<"      "<<setw(2)<<sunnyB<<" Sunny  Days."<<endl;
    cout<<"      "<<setw(2)<<rainB<<" Rainy  Days."<<endl;
    cout<<"      "<<setw(2)<<cloudB<<" Cloudy Days."<<endl;
    cout<<"In August, there were:"<<endl;
    cout<<"      "<<setw(2)<<sunnyC<<" Sunny  Days."<<endl;
    cout<<"      "<<setw(2)<<rainC<<" Rainy  Days."<<endl;
    cout<<"      "<<setw(2)<<cloudC<<" Cloudy Days."<<endl;
    if(grRain==0){
        cout<<"All 3 months had same amount of rainy days."<<endl;
    }
    if(grRain==1){
        cout<<"June had the most amount of rainy days."<<endl;
    }
    if(grRain==2){
        cout<<"July had the most amount of rainy days."<<endl;
    }
    if(grRain==3){
        cout<<"August had the most amount of rainy days."<<endl;
    }
    //Exit stage right!
    return 0;
}
void  fillAry(char array[][COLSMAX]){
    //Open File
    ifstream input;
    input.open("RainOrShine.txt");
    //Filling in the array
    for(int i=0;i<3;i++){
        for(int j=0;j<COLSMAX;j++){
            input>>array[i][j];
        }
    }
    //Close File
    input.close();
}
