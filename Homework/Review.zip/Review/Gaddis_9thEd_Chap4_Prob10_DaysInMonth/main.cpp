/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 27, 2018, 8:09 PM
 * Purpose: Displaying number of days in Month
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
int convert(int, int);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    int month,
        days,
        year;
    //User Input
    cout<<"This program shows number of days in a certain months."<<endl;
    cout<<"Please enter a month (1-12)."<<endl;
    cin>>month;
    cout<<"Please enter a year."<<endl;
    cin>>year;
    //Process/Map inputs to outputs
    days = convert(month,year);
    
    //Output data
    cout<<days<<" days."<<endl;
    //Exit stage right!
    return 0;
}
int convert(int mnth, int yr){
    int day;
    if (yr%100==0){
        if(yr%400==0){
            switch(mnth){
            case 12:day=31;break;
            case 11:day=30;break;
            case 10:day=31;break;
            case 9:day=30;break;
            case 8:day=31;break;
            case 7:day=31;break;
            case 6:day=30;break;
            case 5:day=31;break;
            case 4:day=30;break;
            case 3:day=31;break;
            case 2:day=29;break;
            case 1:day=31;break;
            }
        }
    }
    else if (!(yr%100==0)){
        if(yr%4==0){
            switch(mnth){
            case 12:day=31;break;
            case 11:day=30;break;
            case 10:day=31;break;
            case 9:day=30;break;
            case 8:day=31;break;
            case 7:day=31;break;
            case 6:day=30;break;
            case 5:day=31;break;
            case 4:day=30;break;
            case 3:day=31;break;
            case 2:day=29;break;
            case 1:day=31;break;
            }
        }
        else {
            switch(mnth){
            case 12:day=31;break;
            case 11:day=30;break;
            case 10:day=31;break;
            case 9:day=30;break;
            case 8:day=31;break;
            case 7:day=31;break;
            case 6:day=30;break;
            case 5:day=31;break;
            case 4:day=30;break;
            case 3:day=31;break;
            case 2:day=28;break;
            case 1:day=31;break;
            }
        }
    }
    return day;
}
