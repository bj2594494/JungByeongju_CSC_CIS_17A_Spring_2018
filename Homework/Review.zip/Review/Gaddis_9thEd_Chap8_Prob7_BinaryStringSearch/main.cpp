/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 28, 2018, 7:02 PM
 * Purpose: Binary String Search
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes
void swap(string &a, string &b);
void sort(string [],int);
int search(string [],string);
//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    string name;
    int place;
    const int NM_NAME=20;
    string names[NM_NAME]={"Collins, Bill","Smith, Bart","Allen, Jim",
                           "Griffin, Jim","Stamey, Marty","Rose, Geri",
                           "Taylor, Terri","Johnson, Jill","Allison, Jeff",
                           "Looney, Joe","Wolfe, Bill","James, Jean","Weaver, Jim",
                           "Pore, Bob","Rutherford, Greg","Javens, Renee",
                           "Harrison, Rose","Setzer,Cathy","Pike, Gordon",
                           "Holland, Beth"};
    
    //Sort Array
    sort(names,NM_NAME);
    //Process/Map inputs to outputs
    cout<<"This program searches name in the array."<<endl;
    cout<<"Please enter name to be searched."<<endl;
    getline(cin,name);
    place=search(names,name);
    
    if(place!=-1){
        cout<<"That name is found at "<<place<<"."<<endl;
    }
    else
        cout<<"That name is not found."<<endl;
    
    //Exit stage right!
    return 0;
}

void swap(string &a, string &b){
    string temp=a;
    a=b;
    b=temp;
}

void sort(string array[],int size){
    int minIndx;
    string minVlue;
    for(int i=0;i<(size-1);i++){
        minIndx=i;
        minVlue=array[i];
        for(int j=i+1;j<size;j++){
            if (array[j]<minVlue){
                minVlue=array[j];
                minIndx=j;
            }
        }
        swap(array[minIndx],array[i]);
    }
}

int search(string array[],string m){
    int first=0,
        last=19,
        middle,
        positn=-1;
    bool found=false;
    
    while(!found&&first<=last){
        middle=(first+last)/2;
        if (array[middle]==m){
            found=true;
            positn=middle;
        }
        else if(array[middle]>m)
            last=middle-1;
        else
            first=middle+1;
    }
    return positn;
}