/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 27, 2018, 7:57 PM
 * Purpose: Converting currency
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) {
    //Declare Variables
    float dollar, //Input value for user in U.S dollar.
          yenConv,//Converting value for yen
          yen,    //Output value in Japanese yen.
          euroCon,//Converting value for euro
          euro;   //Output value in euro.
    //Initialize Variables
    yenConv=98.93;
    euroCon=.74;
    //User Input
    cout<<"This program converts U.S dollar to Japanese yen and euro."<<endl;
    cout<<"Please enter the value you wish to convert in U.S dollar."<<endl;
    cin>>dollar;
    //Process/Map inputs to outputs
    yen=dollar*yenConv;
    euro=dollar*euroCon;
    //Output data
    cout<<fixed<<setprecision(2)<<endl;
    cout<<"U.S $"<<dollar<<" = "<<yen<<" yen."<<endl;
    cout<<"U.S $"<<dollar<<" = "<<euro<<" euro."<<endl;
    //Exit stage right!
    return 0;
}

