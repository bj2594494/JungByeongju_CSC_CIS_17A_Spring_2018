/* 
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on February 21, 2018, 1:37 PM
 * Purpose:  Base Converter
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"Base 16, ABC = Base 10, 2748 = Base 8, 5274 = Base 2, 101010111100."<<endl;
    cout<<"Base 10, 678 = Base 16,  2A6 = Base 8, 1246 = Base 2, 001010100110."<<endl;
    //Exit
    return 0;
}

