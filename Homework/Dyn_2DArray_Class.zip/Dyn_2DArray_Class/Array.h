/* 
 * Author: Byeongju Jung
 * Created on March 28th, 2018, 7:41 PM
 * Purpose:  Dynamic 2-D Array with Class
 */

#ifndef ARRAY_H
#define ARRAY_H

class Array{
    private:
        int rows;
        int cols;
        int **data;
    public:
        Array(int,int);
        ~Array(){delete []data;}
        int getData(int,int)const;
        int getRows()const{return rows;}
        int getCols()const{return cols;}
};

#endif /* ARRAY_H */

