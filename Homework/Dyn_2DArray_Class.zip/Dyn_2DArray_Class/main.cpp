/* 
 * Author: Byeongju Jung
 * Created on March 28th, 2018, 7:41 PM
 * Purpose:  Dynamic 2-D Array with Class
 */

//System Libraries
#include <iostream>  //I/O Library
#include <cstdlib>   //srand, rand
#include <ctime>

#include "Array.h"     //Time
using namespace std;

//User Libraries

//Global Constants - Math, Science, Conversions, 2D Array Sizes

//Function Prototypes
void prntAry(const Array *);

//Executions Begin Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare and allocate memory for the array
    int row=10,col=20;
    Array *array;
    array=new Array(row,col);
    
    //Print the random 2-Digit array
    prntAry(array);
    
    //Deallocate memory
    delete array;

    return 0;
}

void prntAry(const Array *a){
    cout<<endl;
    for(int i=0;i<a->getRows();i++){
        for(int j=0;j<a->getCols();j++){
            cout<<a->getData(i,j)<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}