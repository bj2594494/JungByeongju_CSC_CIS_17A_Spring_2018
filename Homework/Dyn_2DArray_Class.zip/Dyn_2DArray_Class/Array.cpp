/* 
 * Author: Byeongju Jung
 * Created on March 28th, 2018, 7:41 PM
 * Purpose:  Dynamic 2-D Array with Class
 */

#include "Array.h"
#include <cstdlib>
#include <ctime>
using namespace std;

Array::Array(int n, int m){
    rows=n<=1?2:n>1000?1000:n;
    cols=m<=1?2:m>1000?1000:m;
    data=new int*[rows];
    for(int i=0;i<rows;i++){
        data[i]=new int[cols];
    }
    for(int j=0;j<rows;j++){
        for(int k=0;k<cols;k++){
            data[j][k]=rand()%90+10;
        }
    }
}   
    
int Array::getData(int indxr,int indxc)const{
    if(indxr>=0&&indxr<rows){
        if(indxc>=0&&indxc<cols){
            return data[indxr][indxc];
        }
    }
    else return data[0][0];
}
