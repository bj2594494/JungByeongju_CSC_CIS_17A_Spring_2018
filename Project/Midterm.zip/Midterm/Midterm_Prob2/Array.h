/*
 * File:   main.cpp
 * Author: Byeongju Jung
 * Created on April 2, 2018, 1:20 PM
 * Purpose: Create a CSC/CIS 5 Template
 */

#ifndef ARRAY_H
#define ARRAY_H

using namespace std;

struct Pay{
    string name;
    int hours;
    int pay;
};

#endif /* ARRAY_H */

