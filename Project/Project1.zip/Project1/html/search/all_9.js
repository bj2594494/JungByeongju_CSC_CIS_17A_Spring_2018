var searchData=
[
  ['valid',['valid',['../main_8cpp.html#af63551d4b1f061a781698cd6ec30c267',1,'main.cpp']]]
];
