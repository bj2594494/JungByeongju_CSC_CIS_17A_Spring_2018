var searchData=
[
  ['write',['write',['../main_8cpp.html#a6767bd763ffee1d8cebf8446c2dbc0b6',1,'main.cpp']]]
];
