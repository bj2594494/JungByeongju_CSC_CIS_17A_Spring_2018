var searchData=
[
  ['cols',['cols',['../struct_array.html#a58cd4e00e6f119ba86c4d5cfc96a85e2',1,'Array']]]
];
