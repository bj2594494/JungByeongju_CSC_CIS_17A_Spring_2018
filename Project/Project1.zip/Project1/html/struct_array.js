var struct_array =
[
    [ "cols", "struct_array.html#a58cd4e00e6f119ba86c4d5cfc96a85e2", null ],
    [ "data", "struct_array.html#add229effce36bcfcbe73658d6fc11dd6", null ],
    [ "rows", "struct_array.html#a4bd58a7d162f10f6c205a26cf00bbc63", null ]
];